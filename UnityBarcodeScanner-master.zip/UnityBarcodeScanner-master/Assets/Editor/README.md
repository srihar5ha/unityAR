# Unity Barcode Scanner

Unity Test Runner (test written with NUnit)