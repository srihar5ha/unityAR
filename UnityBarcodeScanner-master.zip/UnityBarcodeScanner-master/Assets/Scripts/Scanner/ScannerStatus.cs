﻿namespace BarcodeScanner.Scanner
{
	public enum ScannerStatus
	{
		Initialize,
		Running,
		Paused
	}
}
