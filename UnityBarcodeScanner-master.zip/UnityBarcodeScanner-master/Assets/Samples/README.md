# Unity Barcode Scanner

For the moment, two samples are available :
* Simple : Just display the camera with possibility to Start / Stop the scan
* Continous : Always running scan with possiblity to scan multiple barcode